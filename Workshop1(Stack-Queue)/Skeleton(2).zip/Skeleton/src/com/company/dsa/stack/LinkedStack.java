package com.company.dsa.stack;

import com.company.dsa.Node;

public class LinkedStack<E> implements Stack<E> {
    private Node<E> top;
    private int size;

    @Override
    public void push(E element) {
        throw new UnsupportedOperationException();
    }

    @Override
    public E pop() {
        throw new UnsupportedOperationException();
    }

    @Override
    public E peek() {
        throw new UnsupportedOperationException();
    }

    @Override
    public int size() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean isEmpty() {
        throw new UnsupportedOperationException();
    }
}
